LR-0--Parser
============

This is a simple implementation of an LR(0) Parser. (using C)
